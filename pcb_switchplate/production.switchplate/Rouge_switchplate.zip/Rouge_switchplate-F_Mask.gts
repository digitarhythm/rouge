G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.8*
G04 #@! TF.CreationDate,2026-05-17T18:12:22+09:00*
G04 #@! TF.ProjectId,Rouge_switchplate,526f7567-655f-4737-9769-746368706c61,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.8) date 2026-05-17 18:12:22*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
